﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using homework_5_6;


namespace UnitedKingstom
{
    public class London : city
    {
        public string name;
        public London()
        {
            name = "London";
            population = 8982000;
        }
    }
}
