﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using homework_5_6;

namespace SouthKorea
{
    public class Seoul : city
    {
        public string name;

        public Seoul()
        {
            name = "Seoul";
            population = 9776000;
        }


    }
}
