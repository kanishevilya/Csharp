﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework_5_6
{
    public class city
    {
        public int population;
        public int Population { get=>population; }
    }
}
