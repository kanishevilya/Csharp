﻿using System;

namespace homework_1_2 {
    public class Program {

        public static void Main(string[] args)
        {
            Problems task =new Problems();
            task.Problem_01();
            task.Problem_02();
            task.Problem_03();
            task.Problem_04();
            task.Problem_05();
            task.Problem_06();
            task.Problem_07();
            
        }


    }


}
